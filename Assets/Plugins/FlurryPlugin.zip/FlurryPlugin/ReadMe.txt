steps:

1. register in flurry.com
2. create app in flurry.com
3. download sdk for android in flurry
4. place the donwloaded flurry sdk in Assets/Plugins/Android folder inside unity3d project
5. open the test scene
6. place you flurry API key in FlurryPluginCaller 
7. building your project for android platform
8. test the demo scene.


if something is wrong or you got some problem using this plugin
contact me at: gigadrillgames@gmail.com

that's all thanks!
Happy Coding
